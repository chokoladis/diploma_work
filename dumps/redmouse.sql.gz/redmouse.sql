--
-- PostgreSQL database dump
--

\restrict ASBwoqmyrSn0Nur1t7s2W2QWBdJx71eWQdHqaNJuFBdiRK7abz0DDnXZjvl8YAL

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Banner; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Banner" (
    id integer NOT NULL,
    title character varying(50) NOT NULL,
    code character varying(50),
    file jsonb NOT NULL,
    description character varying(255),
    sort smallint DEFAULT 100,
    section character varying(40),
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Banner" OWNER TO root;

--
-- Name: Banner_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Banner_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Banner_id_seq" OWNER TO root;

--
-- Name: Banner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Banner_id_seq" OWNED BY public."Banner".id;


--
-- Name: Basket; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Basket" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    order_id integer,
    product_id integer NOT NULL,
    qty smallint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public."Basket" OWNER TO root;

--
-- Name: Basket_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Basket_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Basket_id_seq" OWNER TO root;

--
-- Name: Basket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Basket_id_seq" OWNED BY public."Basket".id;


--
-- Name: Discount; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Discount" (
    id integer NOT NULL,
    order_id integer NOT NULL,
    title character varying(150) NOT NULL,
    type character varying(50) NOT NULL,
    percent smallint NOT NULL,
    value real NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public."Discount" OWNER TO root;

--
-- Name: Discount_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Discount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Discount_id_seq" OWNER TO root;

--
-- Name: Discount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Discount_id_seq" OWNED BY public."Discount".id;


--
-- Name: Menu; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Menu" (
    id integer NOT NULL,
    title character varying(30) NOT NULL,
    code character varying(30) NOT NULL,
    link character varying(255) NOT NULL,
    sort smallint DEFAULT 100,
    active boolean DEFAULT true NOT NULL,
    level smallint DEFAULT 0,
    area character varying(40),
    parent_id integer
);


ALTER TABLE public."Menu" OWNER TO root;

--
-- Name: Menu_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Menu_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Menu_id_seq" OWNER TO root;

--
-- Name: Menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Menu_id_seq" OWNED BY public."Menu".id;


--
-- Name: Order; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Order" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    status character varying(20) NOT NULL,
    base_price real NOT NULL,
    total_price real NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public."Order" OWNER TO root;

--
-- Name: Order_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Order_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Order_id_seq" OWNER TO root;

--
-- Name: Order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Order_id_seq" OWNED BY public."Order".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    login character varying(60) NOT NULL,
    email character varying(200) NOT NULL,
    phone character varying(12),
    password character varying(200) NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public."User" OWNER TO root;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO root;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: Banner id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Banner" ALTER COLUMN id SET DEFAULT nextval('public."Banner_id_seq"'::regclass);


--
-- Name: Basket id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Basket" ALTER COLUMN id SET DEFAULT nextval('public."Basket_id_seq"'::regclass);


--
-- Name: Discount id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Discount" ALTER COLUMN id SET DEFAULT nextval('public."Discount_id_seq"'::regclass);


--
-- Name: Menu id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Menu" ALTER COLUMN id SET DEFAULT nextval('public."Menu_id_seq"'::regclass);


--
-- Name: Order id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Order" ALTER COLUMN id SET DEFAULT nextval('public."Order_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Banner; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Banner" (id, title, code, file, description, sort, section, active) FROM stdin;
1	Фотография на холсте	\N	{"ext": "jpg", "name": "siTZq1kBiWM.jpg", "path": "/assets/img/slider/siTZq1kBiWM.jpg"}	от 800 ₽	100	\N	t
2	Печать на кружке	\N	{"ext": "jpg", "name": "SJlh96DyOBg.jpg", "path": "/assets/img/slider/SJlh96DyOBg.jpg"}	от 250 ₽	100	\N	t
3	Печать на одежде	\N	{"ext": "jpg", "name": "fsT7ZAW7ywc.jpg", "path": "/assets/img/slider/fsT7ZAW7ywc.jpg"}	от 300 ₽	100	\N	t
4	Сообщения, доклады	\N	{"ext": "jpg", "name": "4-x3uC3c0BQ.jpg", "path": "/assets/img/slider/4-x3uC3c0BQ.jpg"}	от 30 ₽	100	\N	t
5	Визитки	\N	{"ext": "jpg", "name": "c_ZIWAEcXnU.jpg", "path": "/assets/img/slider/c_ZIWAEcXnU.jpg"}	1 ₽/шт.	100	\N	t
\.


--
-- Data for Name: Basket; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Basket" (id, user_id, order_id, product_id, qty, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Discount; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Discount" (id, order_id, title, type, percent, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Menu; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Menu" (id, title, code, link, sort, active, level, area, parent_id) FROM stdin;
1	Услуги	services	/catalog/	100	t	0	header	\N
2	Прайс-лист	prices	/prices/	100	t	0	header	\N
3	Отзывы	reviews	/reviews/	100	t	0	header	\N
4	Отследить трек-код	trek-codes	/trek-codes/	100	t	0	header	\N
5	О нас	about	/about/	100	t	0	header	\N
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Order" (id, user_id, status, base_price, total_price, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."User" (id, login, email, phone, password, email_verified, active, role, created_at, updated_at) FROM stdin;
1	erick63@example.com	erick63@example.com	\N	$argon2id$v=19$m=65536,t=4,p=1$eEdBR0l2RG9RUXdrc0xRZA$j1SZX4pL/9gEkwEUgMbHWidSNb3bhPGVmxCzE9xfZng	f	t	admin	2026-03-10 11:34:00.513977+00	\N
\.


--
-- Name: Banner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Banner_id_seq"', 5, true);


--
-- Name: Basket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Basket_id_seq"', 1, false);


--
-- Name: Discount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Discount_id_seq"', 1, false);


--
-- Name: Menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Menu_id_seq"', 5, true);


--
-- Name: Order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Order_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, true);


--
-- Name: Banner Banner_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Banner"
    ADD CONSTRAINT "Banner_pkey" PRIMARY KEY (id);


--
-- Name: Basket Basket_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Basket"
    ADD CONSTRAINT "Basket_pkey" PRIMARY KEY (id);


--
-- Name: Discount Discount_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Discount"
    ADD CONSTRAINT "Discount_pkey" PRIMARY KEY (id);


--
-- Name: Menu Menu_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Menu"
    ADD CONSTRAINT "Menu_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: User User_email_key; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_email_key" UNIQUE (email);


--
-- Name: User User_login_key; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_login_key" UNIQUE (login);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Basket Basket_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Basket"
    ADD CONSTRAINT "Basket_order_id_fkey" FOREIGN KEY (order_id) REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Basket Basket_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Basket"
    ADD CONSTRAINT "Basket_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id);


--
-- Name: Discount Discount_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Discount"
    ADD CONSTRAINT "Discount_order_id_fkey" FOREIGN KEY (order_id) REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Order Order_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict ASBwoqmyrSn0Nur1t7s2W2QWBdJx71eWQdHqaNJuFBdiRK7abz0DDnXZjvl8YAL

